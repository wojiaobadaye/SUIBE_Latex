# 简洁的美

我觉得吧，相比本科，我的审美变了。。。。之前 本科毕业答辩那个模板：`yuhldr/LZUBeamer` 好丑……

> 其他学校换个logo就可以用

预览：

> 根据 [ldr-simple-gray.cls](./ldr-simple-gray.cls) 里注释掉内容，换换字体会好看很多

预览|字体修改前|字体修改后|
:-:|:-:|:-:
1|![第1页](./images/ppt1.jpg)|![第4页](./images/ppt1_.jpg)
4|![第1页](./images/ppt4.jpg)|![第4页](./images/ppt4_.jpg)


还可以吧，star一下？
